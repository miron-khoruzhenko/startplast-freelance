

import icon0 from '/src/assets/home/news/img0.jpg'
import icon1 from '/src/assets/home/news/img1.jpg'
import icon2 from '/src/assets/home/news/img2.jpg'

const news_data = [
	{
		index: 0,
		title: "Blog title heading will go here",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros.",
		img: icon0,
	},
	{
		index: 1,
		title: "Blog title heading will go here",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros.",
		img: icon1,
	},
	{
		index: 2,
		title: "Blog title heading will go here",
		text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros.",
		img: icon2,
	},

];

export default news_data