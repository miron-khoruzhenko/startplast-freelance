import img0  from '/src/assets/products/productGridHQ/img0.jpg'
import img1  from '/src/assets/products/productGridHQ/img1.jpg'
import img2  from '/src/assets/products/productGridHQ/img2.jpg'
import img3  from '/src/assets/products/productGridHQ/img3.jpg'
import img4  from '/src/assets/products/productGridHQ/img4.jpg'
import img5  from '/src/assets/products/productGridHQ/img5.jpg'
import img6  from '/src/assets/products/productGridHQ/img6.jpg'
import img7  from '/src/assets/products/productGridHQ/img7.jpg'
import img8  from '/src/assets/products/productGridHQ/img8.jpg'
import img9  from '/src/assets/products/productGridHQ/img9.jpg'
import img10 from '/src/assets/products/productGridHQ/img10.jpg'
import img11 from '/src/assets/products/productGridHQ/img11.jpg'

const product_list_db = [
	{
		index: 0,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product1',
		img: img0
	},
	{
		index: 1,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product2',
		img: img1
	},
	{
		index: 2,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product3',
		img: img2
	},
	{
		index: 3,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product4',
		img: img3
	},
	{
		index: 4,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product5',
		img: img4
	},
	{
		index: 5,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product6',
		img: img5
	},
	{
		index: 6,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product7',
		img: img6
	},
	{
		index: 7,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product8',
		img: img7
	},
	{
		index: 8,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product9',
		img: img8
	},
	{
		index: 9,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product10',
		img: img9
	},
	{
		index: 10,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product11',	
		img: img10
	},
	{
		index: 11,
		title: 'Product name',
		descr: '500 pcs in 1 pack',
		price: '€55',
		href: '/products/product12',
		img: img11
	},
]

export default product_list_db