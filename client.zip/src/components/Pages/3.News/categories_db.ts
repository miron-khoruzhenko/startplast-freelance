const categories_db = [
	{
		index: 0,
		title: "View all",
	},
	{
		index: 1,
		title: "News",
	},
	{
		index: 2,
		title: "Sustainability",
	},
	{
		index: 3,
		title: "Trends",
	},
	{
		index: 4,
		title: "Projects",
	}
]

export default categories_db