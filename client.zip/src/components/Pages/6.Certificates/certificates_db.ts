const certificates = [
	{
		index: 0,
		title: "Certificate from Terviseamet AS",
		href: "https://starplast.ee/wp-content/uploads/2021/02/KL2019_PM1465M-analu%CC%88u%CC%88s.pdf"
	},
	{
		index: 1,
		title: "Certificate from UAB Retal Lithuania",
		href: "https://starplast.ee/wp-content/uploads/2021/02/Spec-Preform-_14-04-2016-RETAL-Lithuania-3.pdf"
	},
	{
		index: 2,
		title: "Certificate from UAB Retal Baltic",
		href: "https://starplast.ee/wp-content/uploads/2021/02/Declaration-of-Conformity-RBC17-0501.pdf"
	},
	{
		index: 3,
		title: "Certificate from Bericap Sp. z.o.o.",
		href: "https://starplast.ee/wp-content/uploads/2021/02/Bericap-sert-2019.pdf"
	},
]
export default certificates