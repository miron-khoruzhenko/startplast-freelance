interface ProductBlockProps {
	title: string,
	descr: string,
	price?: string,
	href: string,
	img: string,
}

export default ProductBlockProps