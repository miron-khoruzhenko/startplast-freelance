export interface NavbarLinks {
	title: string,
	link: string,
	index: number
}